package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SmsNotification extends AppCompatActivity {
    TextView smsText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_notification);

        smsText = findViewById(R.id.smsText);
        smsText.setText("This is the SMS Notification screen.");
    }
}
