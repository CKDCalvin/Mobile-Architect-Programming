package com.example.inventoryapp;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;


public class DataDisplay extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        Button smsButton = findViewById(R.id.smsButton);

        Button addButton = findViewById(R.id.addButton);

        addButton.setOnClickListener(v -> {

        });

        smsButton.setOnClickListener(v -> {

        });
    }
}
