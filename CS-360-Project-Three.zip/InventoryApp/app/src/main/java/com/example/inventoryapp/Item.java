package com.example.inventoryapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

// Represents an Inventory Item
@Entity(tableName = "items")
public class Item {
    @PrimaryKey(autoGenerate = true)
    private int id; // Unique ID for the item
    private String name; // Item name
    private int amount; // Quantity

    public Item(String name, int amount) {
        this.name = name;
        this.amount = amount;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAmount() { return amount; }

    public void setId(int id){
        this.id = id;
    }
    public void setAmount(int amount) { this.amount = amount; }
}
