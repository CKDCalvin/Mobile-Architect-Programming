package com.example.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import android.content.pm.PackageManager;

public class SmsNotification extends AppCompatActivity {

    private TextView smsText;

    private Button backButton;

    private final ActivityResultLauncher<String> requiresSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if(isGranted){
                    smsText.setText("SMS permission granted!");
                    // Logic to send SMS here
                } else {
                    smsText.setText("SMS permission denied.");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_notification);

        smsText = findViewById(R.id.smsText);
        requestOrExplainPermission();

        backButton = findViewById(R.id.backButton);


        backButton.setOnClickListener(v -> startActivity(
                new Intent(SmsNotification.this, Inventory.class)));
    }

    private void requestOrExplainPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            smsText.setText("SMS permission already granted.");
            // send SMS logic here
        } else {
            requiresSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

}
