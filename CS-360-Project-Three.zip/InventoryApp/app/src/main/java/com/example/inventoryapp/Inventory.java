package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import java.util.List;
public class Inventory extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private List<Item> itemList;
    private Button addButton, smsButton, logoutButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_display);


        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "inventory_app_db")
                .allowMainThreadQueries()
                .build();

        // Load all items from database
        itemList = db.itemDao().getAll();

        adapter = new ItemAdapter(itemList, db);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        addButton = findViewById(R.id.addButton);
        smsButton = findViewById(R.id.smsButton);
        logoutButton = findViewById(R.id.logoutButton);

        addButton.setOnClickListener(v -> startActivity(new Intent(Inventory.this, DataDisplay.class)));
        smsButton.setOnClickListener(v -> startActivity(new Intent(Inventory.this, SmsNotification.class)));
        logoutButton.setOnClickListener(v -> startActivity(new Intent(Inventory.this, MainActivity.class)));
    }

}
