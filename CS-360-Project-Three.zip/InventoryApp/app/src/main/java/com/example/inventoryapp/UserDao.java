package com.example.inventoryapp;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

// Data Access Object for User table
@Dao
public interface UserDao {
    @Insert
    void insert(User user);

    // Login query
    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    User login(String username, String password);

    // Find user by username
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    User findByUsername(String username);
}
