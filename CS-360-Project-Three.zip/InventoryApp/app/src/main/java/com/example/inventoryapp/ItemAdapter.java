package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.DataViewHolder> {

    private List<Item> itemList;
    private AppDatabase db;

    public ItemAdapter(List<Item> itemList, AppDatabase db){
        this.itemList = itemList;
        this.db = db;
    }

    public static class DataViewHolder extends RecyclerView.ViewHolder {
        TextView itemText;
        EditText amountInput;
        Button updateButton, deleteButton;

        public DataViewHolder(View itemView){
            super(itemView);
            itemText = itemView.findViewById(R.id.itemText);
            amountInput = itemView.findViewById(R.id.amountInput);
            updateButton = itemView.findViewById(R.id.updateButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    @NonNull
    @Override
    public DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.data_row_item, parent, false);
        return new DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DataViewHolder holder, int position){
        Item item = itemList.get(position);
        holder.itemText.setText(item.getName());
        holder.amountInput.setText(String.valueOf(item.getAmount()));

        holder.deleteButton.setOnClickListener(v -> {
            db.itemDao().delete(item);
            itemList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, itemList.size());
        });

        holder.updateButton.setOnClickListener(v -> {
            String updatedAmountStr = holder.amountInput.getText().toString();
            if(!updatedAmountStr.isEmpty()){
                int updatedAmount = Integer.parseInt(updatedAmountStr);
                item.setAmount(updatedAmount);
                db.itemDao().update(item);
                notifyItemChanged(position);
            }
        });
    }

    @Override
    public int getItemCount(){
        return itemList.size();
    }
}
