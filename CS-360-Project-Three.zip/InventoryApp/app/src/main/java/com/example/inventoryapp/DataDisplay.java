package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;
import java.util.List;

public class DataDisplay extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ItemAdapter adapter;
    private List<Item> itemList;
    private EditText newItemInput, newAmountInput;
    private Button addButton, backButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display);

        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "inventory_app_db")
                .allowMainThreadQueries()
                .build();

        // Load all items from database
        itemList = db.itemDao().getAll();

        adapter = new ItemAdapter(itemList, db);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        newItemInput = findViewById(R.id.newItemInput);
        newAmountInput = findViewById(R.id.newAmountInput);
        addButton = findViewById(R.id.addButton);
        //smsButton = findViewById(R.id.smsButton);
        backButton = findViewById(R.id.backButton);

        addButton.setOnClickListener(v -> {
            String name = newItemInput.getText().toString().trim();
            String amountStr = newAmountInput.getText().toString().trim();
            if(!name.isEmpty() && !amountStr.isEmpty()){
                int amount = Integer.parseInt(amountStr);
                Item item = new Item(name, amount);
                db.itemDao().insert(item);
                itemList.clear();
                itemList.addAll(db.itemDao().getAll());
                adapter.notifyDataSetChanged();
                newItemInput.setText("");
                newAmountInput.setText("");
            }
        });

        backButton.setOnClickListener(v -> startActivity(new Intent(DataDisplay.this, Inventory.class)));
    }
}
