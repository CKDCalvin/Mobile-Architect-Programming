package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private Button loginButton, signUpButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = Room.databaseBuilder(getApplicationContext(),
                        AppDatabase.class, "inventory_app_db")
                .allowMainThreadQueries()
                .build();

        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);

        loginButton.setOnClickListener(v -> {
            String u = usernameInput.getText().toString().trim();
            String p = passwordInput.getText().toString().trim();

            if(u.isEmpty() || p.isEmpty()){
                Toast.makeText(this, "Enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            User user = db.userDao().login(u, p);
            if(user != null){
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(MainActivity.this, Inventory.class));
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        signUpButton.setOnClickListener(v -> {
            String u = usernameInput.getText().toString().trim();
            String p = passwordInput.getText().toString().trim();

            if(u.isEmpty() || p.isEmpty()){
                Toast.makeText(this, "Enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            User existing = db.userDao().findByUsername(u);
            if(existing != null){
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            } else {
                User newUser = new User();
                newUser.username = u;
                newUser.password = p;
                db.userDao().insert(newUser);
                Toast.makeText(this, "Account created successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
