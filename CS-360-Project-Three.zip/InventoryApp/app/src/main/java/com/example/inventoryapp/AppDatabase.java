package com.example.inventoryapp;

import androidx.room.Database;
import androidx.room.RoomDatabase;

// Room database for the app
@Database(entities = {User.class, Item.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    // Access to User table
    public abstract UserDao userDao();

    // Access to Item table
    public abstract ItemDao itemDao();
}
